<?php
// login/login.php
session_start();
// El código HTML usará las variables de sesión generadas por login_proceso.php
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceso de Personal - Docraul</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            /* Estilo para un fondo profesional */
            background-color: #f3f4f6;
            background-image: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('../images/dentista.jpg'); 
            background-size: cover; 
            background-position: center; 
            background-attachment: fixed;
        }
    </style>
</head>
<body> 
    
    <div class="flex items-center justify-center min-h-screen p-4">

        <div class="w-full max-w-sm p-8 space-y-6 bg-white rounded-xl shadow-2xl">
            
            <h2 class="text-3xl font-bold text-center text-[#C62828]">Acceso Docraul</h2>
            <p class="text-center text-gray-600">Panel de Recepción</p>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative text-sm" role="alert">
                    <?= htmlspecialchars($_SESSION['error']); ?>
                </div>
            <?php unset($_SESSION['error']); // Limpiar el error después de mostrarlo
            endif; ?>
            <form class="space-y-6" action="../api/login_proceso.php" method="POST"> 
                
                <div>
                    <label for="username" class="block text-sm font-medium text-gray-700">Usuario</label>
                    <input type="text" id="username" name="username" required 
                           class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-[#C62828] focus:border-[#C62828] transition duration-150">
                </div>

                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700">Contraseña</label>
                    <input type="password" id="password" name="password" required 
                           class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-[#C62828] focus:border-[#C62828] transition duration-150">
                </div>

                <div>
                    <button type="submit" 
                            class="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-[#C62828] hover:bg-[#B71C1C] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#C62828] transition duration-150">
                        Iniciar Sesión
                    </button>
                </div>
            </form>

            <div class="text-center pt-2">
                <a href="../index.html" class="text-sm font-medium text-gray-500 hover:text-[#C62828] transition duration-150">
                    ← Volver a la página principal
                </a>
            </div>
        </div>
    </div>
</body>
</html>