<?php
// config/db.php

// --- CONFIGURACIÓN DE LA BASE DE DATOS ---
$host = 'localhost'; // O la IP de tu servidor de BD
$dbname = 'clinica'; // Nombre de la BD
$user = 'root'; // Usuario de la BD
$password = ''; // 

try {
    // Crear la conexión PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    
    // Configurar el modo de error para excepciones (facilita el debug)
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
} catch (PDOException $e) {
    // Si la conexión falla, detiene la ejecución y devuelve un mensaje de error legible
    die("Error de conexión a la base de datos: " . $e->getMessage());
}
?>