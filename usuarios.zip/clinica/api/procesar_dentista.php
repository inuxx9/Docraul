<?php
// api/procesar_dentista.php
session_start();
require_once '../config/db.php'; 

// 1. Verificar Rol y Método
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'recepcionista' || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = "Acceso no autorizado.";
    header('Location: ../login/login.php');
    exit;
}

// 2. Extracción de Datos
$nombre = trim($_POST['nombre'] ?? '');
$especialidad = trim($_POST['especialidad'] ?? '');
$usuario = trim($_POST['usuario'] ?? '');
$password = $_POST['password'] ?? ''; 

// Guardar inputs en sesión, en caso de error de validación/duplicidad
$_SESSION['input'] = ['nombre' => $nombre, 'especialidad' => $especialidad, 'usuario' => $usuario];


// 3. Validación y Hash
if (empty($nombre) || empty($especialidad) || empty($usuario) || empty($password) || strlen($password) < 8) {
    $_SESSION['error'] = "Todos los campos son obligatorios y la contraseña debe tener al menos 8 caracteres.";
    header('Location: ../recepcionista/agregar_dentista.php');
    exit;
}

$password_hash = password_hash($password, PASSWORD_DEFAULT);

try {
    // INICIAR TRANSACCIÓN
    $pdo->beginTransaction();

    // A. Insertar en la tabla 'usuarios' para generar el ID
    $sql_usuario = "INSERT INTO usuarios (usuario, password_hash, rol, fecha_registro) VALUES (?, ?, 'dentista', NOW())";
    $stmt_usuario = $pdo->prepare($sql_usuario);
    $stmt_usuario->execute([$usuario, $password_hash]);

    // OBTENER EL ID DEL USUARIO INSERTADO
    $usuario_id = $pdo->lastInsertId(); 

    // B. Insertar en la tabla 'dentistas' Y VINCULAR CON usuario_id
    // (Asume que la tabla dentistas tiene la columna usuario_id)
    $sql_dentista = "INSERT INTO dentistas (usuario_id, nombre, especialidad) VALUES (?, ?, ?)";
    $stmt_dentista = $pdo->prepare($sql_dentista);
    $stmt_dentista->execute([$usuario_id, $nombre, $especialidad]);
    
    // Finalizar la Transacción
    $pdo->commit();

    // 4. ÉXITO
    unset($_SESSION['input']); // Limpiar inputs guardados
    $_SESSION['success'] = "✅ El Dr(a). {$nombre} ha sido registrado con éxito. Su usuario es '{$usuario}'.";
    
} catch (PDOException $e) {
    // Revertir los cambios si algo falló
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    // Manejar error de usuario duplicado (código SQLSTATE 23000)
    if ($e->getCode() == '23000') {
         $_SESSION['error'] = "❌ Error: El nombre de usuario '{$usuario}' ya existe. Por favor, elige otro.";
    } else {
        error_log("Error al registrar dentista y usuario: " . $e->getMessage());
        $_SESSION['error'] = "❌ Error en el servidor al completar el registro. Inténtalo de nuevo. (Revisa la estructura de la tabla dentistas: debe tener la columna 'usuario_id').";
    }
    
    // La variable $_SESSION['input'] se mantiene para rellenar el formulario.
    header('Location: ../recepcionista/agregar_dentista.php');
    exit;
}

// 5. Redirigir Éxito
header('Location: ../recepcionista/dashboard.php');
exit;
?>