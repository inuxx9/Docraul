<?php
// api/login_proceso.php
session_start();
require_once '../config/db.php'; // Incluye la conexión PDO

// 1. Limpiar mensajes de sesión
unset($_SESSION['error']);
unset($_SESSION['success']);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $usuario = $_POST['username'] ?? ''; 
    $password = $_POST['password'] ?? ''; 

    if (empty($usuario) || empty($password)) {
        $_SESSION['error'] = "Por favor, ingresa usuario y contraseña.";
        header('Location: ../login/login.php'); 
        exit;
    }

    try {
        // 2. Buscar el usuario en la BD
        $stmt = $pdo->prepare('SELECT usuario_id, password_hash, rol FROM usuarios WHERE usuario = :usuario');
        $stmt->execute(['usuario' => $usuario]);
        $user_data = $stmt->fetch();

        // 3. Verificar Contraseña y Rol
        if ($user_data && password_verify($password, $user_data['password_hash'])) {
            
            // Contraseña correcta.
            if ($user_data['rol'] === 'recepcionista') {
                
                // Inicio de sesión exitoso
                $_SESSION['user_id'] = $user_data['usuario_id'];
                $_SESSION['rol'] = $user_data['rol'];
                
                // Redirigir al panel de la recepcionista
                header('Location: ../recepcionista/dashboard.php'); 
                exit;
                
            } else {
                // Rol incorrecto 
                $_SESSION['error'] = "Acceso denegado. Tu rol no es Recepcionista.";
                header('Location: ../login/login.php'); 
                exit;
            }

        } else {
            // Credenciales inválidas
            $_SESSION['error'] = "Usuario o contraseña inválida.";
            header('Location: ../login/login.php'); 
            exit;
        }
    } catch (PDOException $e) {
        error_log("Error de login en BD: " . $e->getMessage());
        $_SESSION['error'] = "Error de servidor. Intenta más tarde.";
        header('Location: ../login/login.php'); 
        exit;
    }
} else {
    // Acceso directo
    header('Location: ../login/login.php');
    exit;
}
?>