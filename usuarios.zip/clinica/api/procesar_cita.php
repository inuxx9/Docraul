<?php
// api/procesar_cita.php
session_start();
require_once '../config/db.php'; 

// 1. Verificación de seguridad
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'recepcionista' || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = "Acceso no autorizado o método incorrecto.";
    header('Location: ../login/login.php'); 
    exit;
}

// 2. Extracción y Validación de datos POST
$cita_id = $_POST['cita_id'] ?? null;
$accion = $_POST['accion'] ?? null;
$dentista_id = $_POST['dentista_id'] ?? null; // Solo se usa para 'asignar'

if (!$cita_id || !$accion) {
    $_SESSION['error'] = "Datos de acción incompletos. Por favor, intenta de nuevo.";
    header('Location: ../recepcionista/dashboard.php');
    exit;
}

try {
    if ($accion === 'rechazar') {
        
        // --- ACCIÓN RECHAZAR ---
        // Cambiar estado a 'Rechazada' y eliminar asignación de dentista.
        $stmt = $pdo->prepare("UPDATE citas SET dentista_id = NULL, estado = 'Rechazada' WHERE cita_id = ? AND estado = 'Pendiente'");
        $stmt->execute([$cita_id]);
        
        if ($stmt->rowCount() > 0) {
            $_SESSION['success'] = "❌ Cita #$cita_id rechazada correctamente.";
        } else {
            $_SESSION['error'] = "⚠️ Error: La cita #$cita_id ya no estaba pendiente.";
        }
        
    } elseif ($accion === 'asignar') {
        
        // --- ACCIÓN ASIGNAR ---
        if (!$dentista_id) {
            $_SESSION['error'] = "Debe seleccionar un dentista para asignar la cita.";
        } else {
            // Cambiar estado a 'Asignada' y asignar dentista.
            $stmt = $pdo->prepare("UPDATE citas SET dentista_id = ?, estado = 'Asignada' WHERE cita_id = ? AND estado = 'Pendiente'");
            $stmt->execute([$dentista_id, $cita_id]);
            
            if ($stmt->rowCount() > 0) {
                $_SESSION['success'] = "✅ Cita #$cita_id asignada y confirmada.";
            } else {
                $_SESSION['error'] = "⚠️ Error: No se pudo asignar la cita #$cita_id.";
            }
        }
    } else {
        $_SESSION['error'] = "Acción de formulario no válida.";
    }

} catch (PDOException $e) {
    error_log("Error de BD al procesar cita: " . $e->getMessage());
    $_SESSION['error'] = "❌ Error de servidor: Fallo en la base de datos.";
}

// Redirección final al dashboard
header('Location: ../recepcionista/dashboard.php'); 
exit;
?>