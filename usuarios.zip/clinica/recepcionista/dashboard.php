<?php
// recepcionista/dashboard.php
session_start();
require_once '../config/db.php'; 

// --- 1. VERIFICACIÓN DE SESIÓN ---
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'recepcionista') {
    header('Location: ../login/login.php'); 
    exit;
}

// --- 2. OBTENER DATOS DE LA BD ---
$citas_pendientes = [];
$dentistas = [];
$error_bd = null;

try {
    $sql_citas = "SELECT 
        c.cita_id, c.fecha_solicitud, c.hora_solicitud, c.motivo, c.estado,
        cl.nombre AS cliente_nombre, cl.telefono AS cliente_telefono
        FROM citas c JOIN clientes cl ON c.cliente_id = cl.cliente_id
        WHERE c.estado = 'Pendiente'
        ORDER BY c.fecha_solicitud ASC, c.hora_solicitud ASC";
    
    $stmt_citas = $pdo->query($sql_citas);
    $citas_pendientes = $stmt_citas->fetchAll();

    $sql_dentistas = "SELECT dentista_id, nombre, especialidad FROM dentistas ORDER BY nombre ASC";
    $stmt_dentistas = $pdo->query($sql_dentistas);
    $dentistas = $stmt_dentistas->fetchAll();

} catch (PDOException $e) {
    error_log("Error al cargar dashboard: " . $e->getMessage());
    $error_bd = "No se pudieron cargar los datos de citas.";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Recepcionista - Docraul</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans leading-normal tracking-normal">

    <header class="bg-[#C62828] shadow-md p-4 flex justify-between items-center">
        <h1 class="text-2xl font-bold text-white">Panel de Recepcionista 🦷</h1>
        <a href="../api/logout.php" class="bg-white text-[#C62828] font-semibold py-1 px-3 rounded-md hover:bg-gray-200 transition">Cerrar Sesión</a>
    </header>

    <main class="container mx-auto mt-8 p-4">
        
        <div class="mb-6 flex justify-between items-center border-b pb-2">
            <h2 class="text-3xl font-semibold text-gray-800">Citas Pendientes (<?= count($citas_pendientes) ?>)</h2>
            
            <a href="agregar_dentista.php" 
               class="bg-blue-600 text-white font-semibold py-2 px-4 rounded-md hover:bg-blue-700 transition shadow-md">
                + Agregar Nuevo Dentista
            </a>
        </div>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4"><?= htmlspecialchars($_SESSION['success']); ?></div>
        <?php unset($_SESSION['success']); endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4"><?= htmlspecialchars($_SESSION['error']); ?></div>
        <?php unset($_SESSION['error']); endif; ?>


        <?php if (isset($error_bd)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert"><strong class="font-bold">Error de Servidor:</strong><span class="block sm:inline"><?= $error_bd ?></span></div>
        <?php elseif (empty($citas_pendientes)): ?>
            <div class="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded relative" role="alert"><span class="block sm:inline">🎉 ¡No hay citas pendientes!</span></div>
        <?php else: ?>
            
            <div class="bg-white shadow-lg rounded-lg overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID Cita</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha/Hora</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Motivo</th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Asignar Dentista</th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Acción</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($citas_pendientes as $cita): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900"><?= htmlspecialchars($cita['cita_id']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><strong><?= date('d/m/Y', strtotime($cita['fecha_solicitud'])) ?></strong><br><?= date('H:i', strtotime($cita['hora_solicitud'])) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><span class="font-medium"><?= htmlspecialchars($cita['cliente_nombre']) ?></span><br>Tel: <?= htmlspecialchars($cita['cliente_telefono']) ?></td>
                            <td class="px-6 py-4 max-w-xs overflow-hidden text-sm text-gray-700"><?= htmlspecialchars($cita['motivo']) ?></td>
                            
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-center">
                                <form action="../api/procesar_cita.php" method="POST" class="flex flex-col space-y-2">
                                    <input type="hidden" name="cita_id" value="<?= $cita['cita_id'] ?>">
                                    <select name="dentista_id" required class="border rounded-md p-2 text-sm focus:ring-[#C62828] focus:border-[#C62828]">
                                        <option value="">Seleccionar...</option>
                                        <?php foreach ($dentistas as $dentista): ?>
                                            <option value="<?= $dentista['dentista_id'] ?>"><?= htmlspecialchars($dentista['nombre']) ?> (<?= htmlspecialchars($dentista['especialidad']) ?>)</option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" name="accion" value="asignar" class="bg-green-600 text-white py-1.5 rounded-md text-xs font-semibold hover:bg-green-700 transition">Asignar y Confirmar</button>
                                </form>
                            </td>

                            <td class="px-6 py-4 whitespace-nowrap text-center">
                                <form action="../api/procesar_cita.php" method="POST">
                                    <input type="hidden" name="cita_id" value="<?= $cita['cita_id'] ?>">
                                    <button type="submit" name="accion" value="rechazar" onclick="return confirm('¿Estás segura de rechazar esta cita?');" class="bg-red-500 text-white py-1 px-3 rounded-md text-xs font-semibold hover:bg-red-600 transition">Rechazar</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
        <?php endif; ?>

    </main>

</body>
</html>