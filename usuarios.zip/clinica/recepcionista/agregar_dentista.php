<?php
// recepcionista/agregar_dentista.php
session_start();
require_once '../config/db.php'; 

// --- 1. VERIFICACIÓN DE SESIÓN ---
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'recepcionista') {
    header('Location: ../login/login.php'); 
    exit;
}

// --- 2. RECUPERACIÓN DE INPUTS EN CASO DE ERROR ---
// Inicializa variables con valores de sesión para rellenar el formulario.
$nombre = $_SESSION['input']['nombre'] ?? '';
$especialidad = $_SESSION['input']['especialidad'] ?? '';
$usuario = $_SESSION['input']['usuario'] ?? '';

// Limpia el array de input después de usarlo.
unset($_SESSION['input']);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Dentista</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Estilos personalizados para el foco */
        .input-focus:focus {
            border-color: #C62828; /* Rojo oscuro de tu header */
            box-shadow: 0 0 0 1px #C62828;
        }
    </style>
</head>
<body class="bg-gray-50 font-sans leading-normal tracking-normal min-h-screen">
    
    <header class="bg-[#C62828] shadow-lg p-4 flex justify-between items-center sticky top-0 z-10">
        <h1 class="text-2xl font-bold text-white">Registro de Dentistas</h1>
        <a href="dashboard.php" 
           class="bg-white text-[#C62828] font-semibold py-1 px-3 rounded-lg hover:bg-gray-200 transition shadow">
            ← Volver al Panel
        </a>
    </header>

    <main class="container mx-auto mt-10 p-4">
        <div class="bg-white shadow-2xl rounded-xl p-8 max-w-2xl mx-auto">
            <h2 class="text-3xl font-extrabold text-gray-800 mb-8 text-center">Registrar Nuevo Profesional</h2>

            <?php // Mensajes de éxito/error ?>
            <?php if (isset($_SESSION['success'])): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4 font-medium"><?= htmlspecialchars($_SESSION['success']); ?></div>
            <?php unset($_SESSION['success']); endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4 font-medium"><?= htmlspecialchars($_SESSION['error']); ?></div>
            <?php unset($_SESSION['error']); endif; ?>
            
            <form action="../api/procesar_dentista.php" method="POST" class="space-y-6">
                
                <fieldset class="border border-gray-200 p-6 rounded-lg">
                    <legend class="text-lg font-semibold text-gray-700 px-2">Datos Profesionales</legend>
                    
                    <div>
                        <label for="nombre" class="block text-sm font-medium text-gray-700 mb-1">Nombre Completo</label>
                        <input type="text" id="nombre" name="nombre" value="<?= htmlspecialchars($nombre) ?>" required 
                               placeholder="Dr. o Dra. Nombre Apellido"
                               class="input-focus mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-3 transition">
                    </div>
                    
                    <div>
                        <label for="especialidad" class="block text-sm font-medium text-gray-700 mb-1">Especialidad</label>
                        <input type="text" id="especialidad" name="especialidad" value="<?= htmlspecialchars($especialidad) ?>" required
                               placeholder="Ej: Ortodoncia, Periodoncia"
                               class="input-focus mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-3 transition">
                    </div>
                </fieldset>

                <fieldset class="border border-gray-200 p-6 rounded-lg">
                    <legend class="text-lg font-semibold text-gray-700 px-2">Creación de Usuario (Acceso al Panel)</legend>

                    <div>
                        <label for="usuario" class="block text-sm font-medium text-gray-700 mb-1">Nombre de Usuario (Login)</label>
                        <input type="text" id="usuario" name="usuario" value="<?= htmlspecialchars($usuario) ?>" required 
                               placeholder="Ej: dentista.roberto"
                               class="input-focus mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-3 transition">
                    </div>
                    
                    <div>
                        <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Contraseña Temporal</label>
                        <input type="password" id="password" name="password" required
                               placeholder="Mínimo 8 caracteres"
                               class="input-focus mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-3 transition">
                    </div>
                </fieldset>
                
                <button type="submit" name="accion" value="agregar"
                        class="w-full bg-green-600 text-white py-3 rounded-lg font-bold text-lg hover:bg-green-700 transition transform hover:scale-[1.01] shadow-lg">
                    🦷 Registrar Dentista y Crear Acceso
                </button>
            </form>
        </div>
    </main>
</body>
</html>